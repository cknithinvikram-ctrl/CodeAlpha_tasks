// Connecting Rod - CodeAlpha Task 1
// Parametric 3D model, dimensions in millimetres
$fn = 128;

// Design parameters
overall_length = 150;
big_outer_d = 40;
big_hole_d = 20;
small_outer_d = 25;
small_hole_d = 12;
rod_width = 15;
thickness = 10;

big_r = big_outer_d/2;
small_r = small_outer_d/2;
center_distance = overall_length - big_r - small_r;

// 2D plan profile: convex hull gives a smooth, tapered connecting web
module rod_profile_2d() {
    hull() {
        translate([big_r, 0]) circle(d=big_outer_d);
        translate([45, 0]) circle(d=rod_width);
        translate([112.5, 0]) circle(d=rod_width);
        translate([big_r + center_distance, 0]) circle(d=small_outer_d);
    }
}

// Main solid with through-holes
module connecting_rod() {
    difference() {
        linear_extrude(height=thickness, center=true)
            rod_profile_2d();

        // Big-end through hole
        translate([big_r, 0, 0])
            cylinder(h=thickness+2, d=big_hole_d, center=true);

        // Small-end through hole
        translate([big_r + center_distance, 0, 0])
            cylinder(h=thickness+2, d=small_hole_d, center=true);
    }
}

connecting_rod();
