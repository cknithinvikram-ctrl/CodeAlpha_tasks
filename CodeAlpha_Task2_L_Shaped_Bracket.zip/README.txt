CODEALPHA TASK 2 — L-SHAPED BRACKET

Files:
- L_Shaped_Bracket.stl: 3D mesh geometry for import/reference.
- L_Shaped_Bracket.scad: editable OpenSCAD source describing the bracket and mounting holes.
- L_Shaped_Bracket_Preview.png: illustrative preview only.
- Task2_FEA_Report_Template.md: report template with blank result fields.

Suggested SolidWorks steps:
1. Import the STL, or recreate the bracket from the SCAD dimensions as a native SolidWorks part.
2. Assign Aluminium Alloy 6061.
3. Enable Tools > Add-Ins > SOLIDWORKS Simulation (if licensed/available).
4. Create a Static study, set realistic fixtures and loads, mesh, and run.
5. Capture actual von Mises stress, displacement, and factor-of-safety plots.
6. Fill the report with values from the solver.

The supplied files do NOT contain verified FEA results or a native .SLDPRT file.
Do not submit the preview as a SolidWorks screenshot or claim the simulation is complete.
