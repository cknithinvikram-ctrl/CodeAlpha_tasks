
// CodeAlpha Task 2 - L-Shaped Bracket
// Units: millimetres
// Concept model for importing/rebuilding in SolidWorks.
// Proposed geometry; validate dimensions and design before engineering use.

$fn = 72;

length = 100;
base_width = 60;
plate_thickness = 10;
upright_height = 70;
hole_diameter = 8;
hole_offset = 20;

module bracket() {
    difference() {
        union() {
            // Horizontal base plate
            cube([length, base_width, plate_thickness]);

            // Vertical plate at rear edge
            translate([0, base_width-plate_thickness, plate_thickness])
                cube([length, plate_thickness, upright_height]);
        }

        // Two base mounting holes, through the base plate
        for (x = [hole_offset, length-hole_offset]) {
            translate([x, base_width/2, -1])
                cylinder(h=plate_thickness+2, d=hole_diameter);
        }

        // Two upright mounting holes, through the vertical plate
        for (x = [hole_offset, length-hole_offset]) {
            translate([x, base_width-plate_thickness-1, plate_thickness+upright_height/2])
                rotate([-90,0,0])
                    cylinder(h=plate_thickness+2, d=hole_diameter);
        }
    }
}

bracket();
