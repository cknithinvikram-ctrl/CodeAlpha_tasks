# TASK 2: STRUCTURAL SIMULATION (FEA)
## Project: Structural Analysis of an L-Shaped Bracket Using SolidWorks

### 1. Objective
Create an L-shaped bracket model and perform a Finite Element Analysis (FEA) to study stress distribution, deformation, and factor of safety.

### 2. Proposed Component and Dimensions
- Component: L-shaped mounting bracket
- Base plate: 100 mm × 60 mm × 10 mm
- Upright plate: 100 mm × 70 mm × 10 mm
- Mounting holes: 8 mm diameter (two on each plate; verify locations in the CAD model)
- Proposed material: Aluminium Alloy 6061

These are proposed educational model dimensions, not certified engineering specifications.

### 3. SolidWorks Workflow
1. Open the bracket STL or recreate the bracket as a native SolidWorks Part.
2. Assign Aluminium Alloy 6061 using the SolidWorks material library.
3. Open the Simulation add-in and create a Static study.
4. Apply a fixed fixture to the mounting face/appropriate mounting-hole regions.
5. Apply a downward force to the free end or selected loading face. Record the exact load and direction used.
6. Create a mesh. Refine the mesh around the inside corner and holes.
7. Run the study.
8. Save plots for von Mises stress, resultant displacement, and factor of safety.
9. Record maximum values, units, mesh size, and assumptions.

### 4. Results (complete only after running SolidWorks Simulation)
- Maximum von Mises stress: __________________ MPa
- Maximum resultant displacement: ____________ mm
- Minimum factor of safety: ___________________
- Applied load and direction: __________________
- Mesh element count / mesh size: ______________

### 5. Observations
Write observations from the actual plots. Identify where the highest stress occurs and where the maximum displacement occurs. Do not estimate or invent these values.

### 6. Conclusion
Complete this section after the SolidWorks study has been run. State whether the bracket meets the chosen design criterion based on the actual stress, displacement, and factor-of-safety results.

### Important
The supplied STL and SCAD files are geometry resources only. They are not a completed FEA simulation. A genuine SolidWorks Simulation run and screenshots are still required before submission.
